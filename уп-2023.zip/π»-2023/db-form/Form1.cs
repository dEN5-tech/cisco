﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_form
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            // Redirect to login page
            Login loginForm = new Login();
            loginForm.ShowDialog();

            // Check if login was successful
            if (loginForm.DialogResult == DialogResult.OK)
            {
                InitializeComponent();
            }
            else
            {
                // Close the form if login was not successful
                this.Close();
            }
        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using db_form.DB;
using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace db_form
{
    public partial class Login : Form
    {
        DatabaseConnection dbConnection;
        OleDbConnection connection;

        public Login()
        {
            InitializeComponent();
            dbConnection = DatabaseConnection.Instance;
            dbConnection.OpenConnection();
            connection = dbConnection.GetConnection();
        }

        //private void BtnLogin_Click(object sender, EventArgs e)
        //{
        //    bool valid = CheckUser(txtUsername.Text, txtPassword.Text);
        //    if (valid)
        //    {
        //        MessageBox.Show("Правильные данные, проходите", "Alert");
        //    }
        //}

        private bool CheckUser(string username, string password)
        {
            bool userExists = false;

            string query = "SELECT COUNT(*) FROM [Клиент] WHERE [Фио] = @Username";
            using (OleDbCommand command = new OleDbCommand(query, dbConnection.GetConnection()))
            {
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Password", password);

                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }

                int count = (int)command.ExecuteScalar();

                connection.Close();

                if (count > 0)
                {
                    userExists = true;
                }
            }

            return userExists;
        }


        private void BtnLogin_Click(object sender, EventArgs e)
        {
            bool valid = CheckUser(txtUsername.Text, txtPassword.Text);
            if (valid)
            {
                MessageBox.Show("Правильные данные, проходите", "Alert");
                panel1.Visible = false;
                panel2.Visible = false;
            }
            else
            {
                MessageBox.Show("Вы ошиблись", "Alert");
            }
        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {
            // Logic for handling the Register button click
            panel1.Visible = false;
            panel2.Visible = true;
        }

        //private void BtnRegister_Click(object sender, EventArgs e)
        //{
        //    // Redirect to login page
        //    Form1 loginForm = new Form1();
        //    loginForm.ShowDialog();

        //    // Check if login was successful
        //    if (loginForm.DialogResult == DialogResult.OK)
        //    {
        //        InitializeComponent();
        //    }
        //    else
        //    {
        //        // Close the form if login was not successful
        //        this.Close();
        //    }
        //}

        private void Login_Load(object sender, EventArgs e)
        {

            //dbConnection.OpenConnection();
        }

        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            //dbConnection.CloseConnection();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            // Logic for handling the Login button click
            panel1.Visible = true;
            panel2.Visible = false;
        }

        private void КлиентBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {

        }

        private void КлиентBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {

        }

        private void Panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
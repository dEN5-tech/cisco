﻿using System;
using System.Data.OleDb;
using System.Windows.Forms;

namespace db_form.DB
{
    public class DatabaseConnection
    {
        private static DatabaseConnection instance;
        private static OleDbConnection connection;
        private static object lockObject = new object();

        private DatabaseConnection()
        {
            // Connection string for Access database
            string binPath = Application.StartupPath;
            var Path = binPath+"\\Database4.accdb";
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source="+ Path+
                ";Jet OLEDB:Database Password=12345678;User ID=Admin;Jet OLEDB:System database=master";

            // Initialize the connection
            connection = new OleDbConnection(connectionString);
        }

        public static DatabaseConnection Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (lockObject)
                    {
                        if (instance == null)
                        {
                            instance = new DatabaseConnection();
                        }
                    }
                }
                return instance;
            }
        }

        public OleDbConnection GetConnection()
        {
            return connection;
        }

        public void OpenConnection()
        {
            try
            {
                // Open the connection
                connection.Open();
                Console.WriteLine("Connection opened successfully.");
            }
            catch (OleDbException ex)
            {
                Console.WriteLine("Error opening connection: " + ex.Message);
            }
        }

        public void CloseConnection()
        {
            try
            {
                // Close the connection
                connection.Close();
                Console.WriteLine("Connection closed successfully.");
            }
            catch (OleDbException ex)
            {
                Console.WriteLine("Error closing connection: " + ex.Message);
            }
        }
    }
}